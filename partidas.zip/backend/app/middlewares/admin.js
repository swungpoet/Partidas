 module.exports = {
 	static: require('./static'),
 	favicon: require('./favicon'),
 	locals: require('./locals')
 }