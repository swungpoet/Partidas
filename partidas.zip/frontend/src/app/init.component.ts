import { Component} from '@angular/core';

@Component({
    selector:'init-component',
    template: '<router-outlet></router-outlet>'                
})
export class InitComponent{}